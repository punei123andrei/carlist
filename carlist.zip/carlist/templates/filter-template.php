
<div class="container">
       <form action="" id="car-listing-form" method="POST">
           <div class="form-group d-flex justify-content-around">
                <select name="fuel" id="c-fuel">
                  <option value="">Select fuel</option>
                   Fuel_options
                </select>
                <select name="brand" id="c-brand">
                  <option value="">Select brand</option>
                  Brand_options
                </select>
                <select name="color" id="c-color">
                  <option value="">Select a color</option>
                  Color_options
                </select>
           </div>
       </form>
</div>

