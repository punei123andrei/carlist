    <div class="car-item-wrapper">
        <div class="car-title">TITLE</div>
        <div class="d-flex justify-content-around fields-wrapper">
            <div class="car-specs car-fuel">
                <p>FUEL_FIELD</p>
            </div>
            <div class="car-specs car-brand">
                <p>BRAND_FIELD</p>
            </div>
            <div class="car-specs car-color">
                <p>COLOR_FIELD</p>
            </div>
        </div>
    </div>

